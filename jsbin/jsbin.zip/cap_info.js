module.exports = {
    tcode:null,
    dstip: '192.168.147.10',//'27.102' , // 
    dstport:'' ,
    svcid:'',
    ptype:'F',
    dstv:null,
    otherCond :'', // ex ->   ' && ( port 80 || 8080 ) '
    norcv:null,
    conn:null,
    maxcnt:5,
    jobId:0
};
